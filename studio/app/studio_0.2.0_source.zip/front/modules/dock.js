const dock = {
    icon: {
        new(icon, app) {
            const dockContent = getEBD('dockContent');
            
            const iconContainer = document.createElement('button');
            iconContainer.id = `${app}-dock`;
            const iconImg = document.createElement('img');
            iconImg.src = icon;
            
            iconContainer.appendChild(iconImg);
            dockContent.appendChild(iconContainer);
            
            // FIX: Use lowercase 'onclick' for DOM element property
            // FIX: Removed the line 'dock.icon.minRes(app);' which was minimizing the app on launch.
            iconContainer.onclick = () => { dock.icon.minRes(app) };
        },
        remove(app) {
            // Added null check for robustness
            const iconElement = getEBD(`${app}-dock`);
            if (iconElement) {
                iconElement.parentNode.removeChild(iconElement);
            }
        },
        minRes(app) {
            // Using boolean values (true/false) for processes state is correct here.
            if (processes[app] === true) {
                minTask(app);
            } else if (processes[app] === false) {
                resTask(app);
            } else {
                // If it's neither true nor false (e.g., undefined, null, or crashed)
                endTask(app);
                noti(`${pretty(app)} Crashed`);
                studio.log.new(`${app} Crashed`);
                return;
            }
        }
    },
    element: getEBD('dock'),
    async open() {
        return new Promise(async (resolve) => {
            const el = dock.element;
            document.body.style.overflow = "hidden";
            el.style.display = "flex";
            await wait(50);
            el.style.bottom = "0";
            await wait(500);
            document.body.style.overflow = "auto";
            resolve();
        });
    },
    async close() {
        return new Promise(async (resolve) => {
            const el = dock.element;
            document.body.style.overflow = "hidden";
            el.style.bottom = "-2.1em";
            await wait(500);
            el.style.display = "none";
            document.body.style.overflow = "auto";
            resolve();
        });
    }
};

const restartBtn = getEBD('restartBtn');
const exitBtn = getEBD('exitBtn');
const taskMgrBtn = getEBD('taskMgrBtn');
const taskMgrCloseBtn = getEBD('taskMgrClose');

if (restartBtn) restartBtn.addEventListener('click', () => {
    studio.log.new("log", "[System] Restart requested");
    location.reload();
});
if (exitBtn) exitBtn.addEventListener('click', studio.exit);
if (taskMgrBtn) taskMgrBtn.addEventListener('click', openTaskMgr);
if (taskMgrCloseBtn) taskMgrCloseBtn.addEventListener('click', closeTaskMgr);