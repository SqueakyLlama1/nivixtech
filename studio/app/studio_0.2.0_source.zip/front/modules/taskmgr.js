const processes = {};
let processAppMeta = {};

// ======================
// Task Management Helper
// ======================

/**
 * Iterates through all running processes and minimizes them, 
 * except for the process matching the provided ID.
 * Assumes the existence of the global 'processes' object and 'minTask(id)' function.
 * @param {string} id - The ID of the application that should NOT be minimized.
 */
function minimizeAllExcept(id) {
    for (const otherAppId in processes) {
        // Check 1: Is it a different app?
        // Check 2: Is the other app currently visible/restored (processes[id] === true)?
        if (otherAppId !== id && processes[otherAppId] === true) {
            minTask(otherAppId); // Minimize the other running app
        }
    }
}

// ======================
// Task Management Core
// ======================

async function newTask(id) {
    // If app is already running, restore it instead of creating new
    if (processes[id]) return resTask(id);
    
    // ✨ CORE CHANGE: Minimize all other windows before launching a new one
    minimizeAllExcept(id); 

    // Ensure getEBD, $, pretty, window.ndutil are defined and available in your environment.

    let appMeta = await window.ndutil.readJSON(`apps/${id}/pkg.json`);
    
    if (appMeta) {
        processAppMeta[id] = {
            "version": appMeta.version
        };
    }
    
    const taskElement = $('<div>', { class: 'task', id: `task-${id}` });
    const taskBar = $('<div>', { class: 'bar' });
    
    // Using jQuery's .on() is good practice here.
    const closeBtn = $('<button>').text('X').on('click', () => endTask(id));
    const minBtn = $('<button>').text('-').on('click', () => minTask(id));
    
    const taskLabel = $('<span>').text(pretty(id));
    
    taskBar.append(taskLabel);
    // Appending buttons in correct order
    taskBar.append(closeBtn, minBtn); 
    taskElement.append(taskBar);
    
    const iframe = $('<iframe>', { src: `apps/${id}/index.html`, id: `task-${id}-iframe` });
    taskElement.append(iframe);
    
    processes[id] = true;
    $('body').append(taskElement);
    
    // Compatibility layer for 0.1.0 (kept as-is)
    let appImgFormat;
    const imgFormat1 = await window.ndutil.fileExists(['apps', id, `${id}.png`]);
    if (imgFormat1) {
        appImgFormat = id;
    } else {
        appImgFormat = "favicon";
    }
    appImg = `apps/${id}/${appImgFormat}.png`;
    
    // NOTE: Requires 'dock.icon.new' to be defined elsewhere
    dock.icon.new(appImg, id); 
    
    // Add 'active' class to the dock icon right after creating it to indicate it's open
    getEBD(`${id}-dock`).classList.add("active");

    // Animation remains the same
    taskElement.css({ opacity: 0, transform: 'scale(0.8)' }).show().animate({ opacity: 1 }, {
        duration: 200,
        step: function(now) {
            const scale = 0.8 + 0.2 * now + 0.05 * Math.sin(now * Math.PI * 3);
            $(this).css('transform', `scale(${scale})`);
        }
    });
}

function minTask(id) {
    const el = $(`#task-${id}`);
    processes[id] = false;
    // Use .remove() to explicitly set state to minimized
    getEBD(`${id}-dock`).classList.remove("active");
    // Removed old top: 0 CSS reset to let the element restore correctly from the animation's top offset
    el.animate({ opacity: 0, top: '+=50px' }, { duration: 200, complete: () => el.hide().css({ top: '0px' }) });
}

function resTask(id) {
    // ✨ CORE CHANGE: Minimize all other windows before restoring this one
    minimizeAllExcept(id); 
    
    const el = $(`#task-${id}`);
    processes[id] = true;
    // Use .add() to explicitly set state to restored
    getEBD(`${id}-dock`).classList.add("active");
    el.show().css({ opacity: 0, top: '50px' });
    el.animate({ opacity: 1, top: '0px' }, { duration: 200 });
}

function endTask(id) {
    const el = $(`#task-${id}`);
    
    delete processes[id];
    delete processAppMeta[id]; // Good practice to clean up app meta data too
    
    // NOTE: Requires 'dock.icon.remove' to be defined elsewhere
    dock.icon.remove(id);
    
    el.animate({ opacity: 0, top: '-=50px' }, {
        duration: 200,
        step: function(now) {
            const scale = 1 - 0.2 * now;
            $(this).css('transform', `scale(${scale})`);
        },
        complete: function() {
            const element = getEBD(`task-${id}`);
            if (element) element.remove();
        }
    });
}

// ======================
// Task Manager GUI Functions
// ======================

async function openTaskMgr() {
    const container = getEBD('taskMgrContainer');
    const content = getEBD('taskMgrContent');
    
    async function loadContent() {
        
        content.innerHTML = "";
        
        // FIX: Use Object.keys() to correctly iterate over the app IDs in the 'processes' object
        for (const app of Object.keys(processes)) {
            const itemContainer = newEl('div');
            const itemImg = newEl('img');
            const itemTextContainer = newEl('div');
            const itemName = newEl('span');
            const itemVer = newEl('span');
            const endTaskBtn = newEl('button');
            
            itemContainer.classList.add('taskMgrItem');
            
            // Compatibility layer for 0.1.0 (kept as-is)
            let appImgFormat;
            const imgFormat1 = await window.ndutil.fileExists(['apps', app, `${app}.png`]);
            if (imgFormat1) {
                appImgFormat = app;
            } else {
                appImgFormat = "favicon";
            }
            itemImg.src = `apps/${app}/${appImgFormat}.png`;
            
            itemTextContainer.classList.add('taskMgrItemText');
            
            itemName.textContent = `App: ${pretty(app)}`;
            
            let itemVersion = null;
            if (processAppMeta[app]?.version) {
                itemVersion = processAppMeta[app].version;
            } else {
                itemVersion = "Not found";
            }
            
            itemVer.textContent = `Version: ${itemVersion}`;
            
            endTaskBtn.innerHTML = `<img src="img/not-allowed.png">End Task`;
            endTaskBtn.onclick = () => {
                try {
                    endTask(app);
                } catch (e) { // Catch the error object for logging
                    noti("Failed to end task");
                    studio.log.new("error", `[TASKMGR] Failed to end task ${app}: ${e}`);
                    loadContent();
                    return;
                }
                if (prefs?.loaded.taskEndNoti) {
                    noti(`Ended task: ${pretty(app)}`);
                }
                loadContent(); // Reload content after successful task end
            };
            
            itemContainer.appendChild(itemImg);
            itemTextContainer.appendChild(itemName);
            itemTextContainer.appendChild(itemVer);
            itemContainer.appendChild(endTaskBtn);
            content.appendChild(itemContainer);
        }
    }
    try {
        // FIX: Check the length of the keys for the object
        if (Object.keys(processes).length > 0) { 
            loadContent();
        } else {
            content.innerHTML = `<div class="middle"><p>No apps are running</p></div>`;
        }
    } catch(err) {
        studio.log.new("error", `[TASKMGR] Failed to open task manager popup: ${err}`);
    }
    
    const containerJQ = $(container);
    
    containerJQ.fadeIn(75);
}

function closeTaskMgr() {
    const container = getEBD('taskMgrContainer');
    const content = getEBD('taskMgrContent');
    
    const containerJQ = $(container);
    
    containerJQ.fadeOut(75, function() {
        content.innerHTML = "";
    });
}